@echo off
setlocal
set "SCRIPT_DIR=%~dp0"
pushd "%SCRIPT_DIR%.."
set "ROOT=%CD%"
popd
set "TARGET=%ROOT%\shltbrwsrhmpg.html"
set "ICON=%ROOT%\ShallotBrowserIcon.ico"
for /f "usebackq tokens=2,*" %%A in (`reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders" /v Desktop`) do (
    set "DESKTOP_PATH=%%B"
)
call set "DESKTOP_PATH=%DESKTOP_PATH%"
set "SHORTCUT=%DESKTOP_PATH%\Shallot Browser.lnk"
echo Target: %TARGET%
echo Icon:   %ICON%
echo Saving to: %SHORTCUT%
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$s=(New-Object -COM WScript.Shell).CreateShortcut('%SHORTCUT%');" ^
  "$s.TargetPath='%TARGET%';" ^
  "$s.IconLocation='%ICON%';" ^
  "$s.Save()"
if %ERRORLEVEL% EQU 0 (
    echo.
    echo Shallot Browser was installed, and the shortcut created on your Desktop.
) else (
    echo.
    echo Failed to create shortcut. Check if the folders/files exist.
)
pause