#!/bin/bash

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TARGET="$ROOT/shltbrwsrhmpg.html"
SHORTCUT="$HOME/Desktop/Shallot Browser"

osascript <<EOF
tell application "Finder"
    make alias file to POSIX file "$TARGET" at POSIX file "$HOME/Desktop"
end tell
EOF

echo "Alias created on your Desktop."