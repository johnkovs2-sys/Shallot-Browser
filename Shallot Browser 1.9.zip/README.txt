|=================================================================================================================|
|   ____   _                _   _              _         _                                                        |
|  //===)  ||               ||  ||             ||        ||==\\                                                   |
| ||       ||               ||  ||             ||        ||   ))  __                          //==          __    |
|  \\=\\   ||==\\   //==\|  ||  ||   //==\\  ======      ||==<<   |//=)  //==\\ \\   /^\   // \\    //==\\  |//=) |
|  ____||  ||  ||  |(   ||  ||  ||  |(    )|   ||        ||   ))  ||    |(    )| \\ // \\ //    \\ |(____/) ||    |
| (====//  ||  ||   \\==|\  ||  ||   \\==//    ||        ||___//  ||     \\==//   \V/   \V/   ==//  \\___,  ||    |
|=================================================================================================================|
|Version 1.9 //
|===========//

Shallot Browser V1.9 Informational Source File
__________________________________________________________________________________________________________________

INSTALL DIRECTIONS

Pre-included installers:
Windows
MacOS
ChromeOS
Universal

	Make sure that you have extracted all files from the .zip package.

	Go into the install folder, at ...\Shallot Browser 1.9\Install\

	Double-click the installer that matches your operating system, or the universal installer.


	If there is an installer missing, you can download it from Download_The_Installers.html
__________________________________________________________________________________________________________________

Shallot Browser is the world's first embedded dynamic iframe browser.

It is a browser inside of your browser. (Edge, Chrome, Firefox, etc.)

Shallot Browser is fully portable.

The entire folder may be moved, copied, or stored on external drives without affecting functionality, as long as
the internal structure remains intact.


There are two main file types unique to Shallot Browser you may need to know about:

	.shlext		These are Shallot Browser extension files, which may be loaded into either persistent
			extensions via data management, or temporarily via Ctrl+o or the Quick Menu.
			Extensions may modify behavior, add features, or enhance browsing.  
			Only install extensions from trusted sources.

	.shlalg		These are Search Algorithms for Availability Search that alter its search priority and
			behavior.


__________________________________________________________________________________________________________________

© johnkovs2@gmail.com 1/26/2026, American Date Format.

All rights reserved.

The creator reserves all rights to any version or variant of Shallot Browser.

All Current, Past, and Future versions of the Shallot Browser project are Protected By Common Copyright Law.

It is illegal to distribute, use, or copy Shallot Browser without explicit permission from the creator.

All files marked read-only are not to be edited or tampered with.

All preexisting files are not to be edited or tampered with.


Shallot Browser is provided as-is without warranty of any kind.  

The creator is not responsible for any misuse, data loss, or system behavior resulting from the use of this
software.


The Shallot Browser Project is not open source.
__________________________________________________________________________________________________________________

INFORMATION FOR DEVELOPERS

You may make your own extensions.
Extensions are raw JavaScript.
The DOM id of the iframe is insetwindow.

You may make your own Search algorithms.
The array consisting of all the separate terms the user searched for is splitUrl.
The function to show results for  https:// + url + all url extensions the user specified  is 
doUrlWithExtensions();.

If you have developed a good algorithm or extension, you may email it to johnkovs2@gmail.com for it to potentially
be listed in the official store.
__________________________________________________________________________________________________________________

You may suggest update ideas, but you may not modify the Shallot Browser files yourself.

For inquiries or permissions, contact: johnkovs2@gmail.com
__________________________________________________________________________________________________________________